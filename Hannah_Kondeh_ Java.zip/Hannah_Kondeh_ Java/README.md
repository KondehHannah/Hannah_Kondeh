# Hannah Kondeh — PROG209 Java Swing Assignment

## Project overview
A Java Swing desktop GUI for the PROG209 Basic Interactive GUI assignment. It uses a cyan-green visual identity and a custom H monogram icon.

## Requirements reflected in the project
- Main class: `SwingAssignment` (one definition only).
- `JFrame` title: `Java Swing Assignment`.
- Initial frame dimensions: 800 × 800 pixels.
- `JFrame.EXIT_ON_CLOSE`.
- `JPanel` variable `panel`, `JLabel` variable `label`, and `ImageIcon` resource.
- Inheritance: `SwingAssignment extends BaseWindow`.
- Constructor: `public SwingAssignment()`.
- Change Text updates the welcome label from user input.
- Change Background switches only between two predefined deep-teal and light-cyan states.
- Reset returns the interface to its initial state.
- No arbitrary colour picker is included.

## Prerequisites
Install a JDK (Java 17 or newer recommended). IntelliJ IDEA or Visual Studio Code with Java support can be used.

## Run in IntelliJ IDEA
1. Open the `Hannah_Kondeh_PROG209` folder as a project.
2. Ensure `resources/hannah_kondeh_H_icon.png` is added to the runtime classpath root so it is available as `/hannah_kondeh_H_icon.png`.
3. Run `sl.edu.prog209.SwingAssignment`.
4. If the icon is not available on the classpath, the interface uses a text H fallback.

## Compile and run from a terminal
From the project root:

```bash
mkdir -p out
javac -d out src/sl/edu/prog209/BaseWindow.java src/sl/edu/prog209/SwingAssignment.java
cp resources/hannah_kondeh_H_icon.png out/
java -cp out sl.edu.prog209.SwingAssignment
```

## Structural smoke check
```bash
javac -d out src/sl/edu/prog209/BaseWindow.java src/sl/edu/prog209/SwingAssignment.java src/sl/edu/prog209/GuiSmokeTest.java
java -cp out sl.edu.prog209.GuiSmokeTest
```
The smoke check checks source structure and restrictions. It does not replace manual GUI testing.

## Manual testing to perform
- Confirm the initial title and 800 × 800 dimensions.
- Confirm the window closes when the close control is clicked.
- Use Change Text with valid text, blank text, and Cancel.
- Click Change Background repeatedly to confirm only the two fixed backgrounds are used.
- Click Reset after changing text/background.
- Confirm the H icon appears in the interface and title bar.
- Compare the running interface with the Figma design.
- Capture genuine screenshots of the Figma frame, source code, running GUI and interactions.

## GitHub submission
Create a repository for this project, commit the source and supporting files, and add the lecturer as a collaborator using the address shown in the official brief. Verify the address before inviting; do not assume the invitation has been sent by this package.
