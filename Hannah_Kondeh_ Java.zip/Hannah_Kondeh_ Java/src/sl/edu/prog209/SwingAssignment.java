package sl.edu.prog209;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.net.URL;


public class SwingAssignment extends BaseWindow {
    private final JPanel panel;
    private final JLabel label;
    private final JLabel statusLabel;

    private static final Color DEEP_TEAL = new Color(8, 34, 44);
    private static final Color CYAN = new Color(43, 220, 207);
    private static final Color MINT = new Color(100, 245, 177);
    private static final Color PALE_MINT = new Color(224, 255, 245);
    private static final Color LIGHT_CYAN = new Color(218, 255, 250);

    private boolean lightBackground = false;

    public SwingAssignment() {
        super();

        panel = new JPanel(new BorderLayout(18, 18));
        panel.setBackground(DEEP_TEAL);
        panel.setBorder(BorderFactory.createEmptyBorder(34, 38, 30, 38));

        URL iconUrl = getClass().getResource("/hannah_kondeh_H_icon.png");
        if (iconUrl != null) {
            ImageIcon appIcon = new ImageIcon(iconUrl);
            frame.setIconImage(appIcon.getImage());
        }

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);

        JLabel eyebrow = new JLabel("PROG209  /  EVENT-DRIVEN PROGRAMMING");
        eyebrow.setForeground(MINT);
        eyebrow.setFont(new Font("SansSerif", Font.BOLD, 13));
        top.add(eyebrow, BorderLayout.NORTH);

        JLabel title = new JLabel("Hannah's Swing Space");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("SansSerif", Font.BOLD, 27));
        title.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 0));
        top.add(title, BorderLayout.CENTER);
        panel.add(top, BorderLayout.NORTH);

        JPanel centre = new JPanel(new BorderLayout(12, 18));
        centre.setOpaque(false);
        centre.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(43, 220, 207, 110), 1),
            BorderFactory.createEmptyBorder(24, 22, 24, 22)
        ));

        JLabel logoLabel = new JLabel();
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        URL resource = getClass().getResource("/hannah_kondeh_H_icon.png");
        if (resource != null) {
            ImageIcon source = new ImageIcon(resource);
            logoLabel.setIcon(new ImageIcon(source.getImage().getScaledInstance(158, 158, java.awt.Image.SCALE_SMOOTH)));
        } else {
            logoLabel.setText("H");
            logoLabel.setForeground(CYAN);
            logoLabel.setFont(new Font("SansSerif", Font.BOLD, 72));
        }
        centre.add(logoLabel, BorderLayout.NORTH);

        label = new JLabel(
            "<html><div style='text-align:center;'>Welcome to Java Swing First<br>"
            + "Individual Assignment by Hannah Kondeh</div></html>",
            SwingConstants.CENTER
        );
        label.setForeground(Color.WHITE);
        label.setFont(new Font("SansSerif", Font.BOLD, 21));
        label.setBorder(BorderFactory.createEmptyBorder(8, 4, 8, 4));
        centre.add(label, BorderLayout.CENTER);

        JLabel helper = new JLabel("A small interface built with Java Swing", SwingConstants.CENTER);
        helper.setForeground(new Color(180, 221, 223));
        helper.setFont(new Font("SansSerif", Font.PLAIN, 14));
        centre.add(helper, BorderLayout.SOUTH);

        panel.add(centre, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(12, 14));
        bottom.setOpaque(false);

        JPanel buttons = new JPanel(new java.awt.GridLayout(1, 3, 12, 0));
        buttons.setOpaque(false);
        JButton changeTextButton = makeButton("Change Text");
        JButton changeBackgroundButton = makeButton("Change Background");
        JButton resetButton = makeButton("Reset");
        buttons.add(changeTextButton);
        buttons.add(changeBackgroundButton);
        buttons.add(resetButton);
        bottom.add(buttons, BorderLayout.CENTER);

        statusLabel = new JLabel("Ready — choose an action above.");
        statusLabel.setForeground(MINT);
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(14, 2, 0, 2));
        bottom.add(statusLabel, BorderLayout.SOUTH);
        panel.add(bottom, BorderLayout.SOUTH);

        changeTextButton.addActionListener(event -> changeLabelText());
        changeBackgroundButton.addActionListener(event -> toggleBackground());
        resetButton.addActionListener(event -> resetInterface());

        frame.setContentPane(panel);
        frame.setMinimumSize(new Dimension(650, 650));
        frame.setVisible(true);
    }

    private JButton makeButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setForeground(DEEP_TEAL);
        button.setBackground(CYAN);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MINT, 1),
            BorderFactory.createEmptyBorder(13, 8, 13, 8)
        ));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMargin(new Insets(8, 8, 8, 8));
        return button;
    }

    private void changeLabelText() {
        String input = JOptionPane.showInputDialog(
            frame,
            "Enter the new welcome text:",
            "Change Label Text",
            JOptionPane.PLAIN_MESSAGE
        );

        if (input == null) {
            statusLabel.setText("Text change cancelled.");
            return;
        }
        String cleaned = input.trim();
        if (cleaned.isEmpty()) {
            statusLabel.setText("No change made: text cannot be blank.");
            return;
        }

        label.setText("<html><div style='text-align:center;'>" + escapeHtml(cleaned) + "</div></html>");
        statusLabel.setText("Welcome label updated.");
    }

    private String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }

    private void toggleBackground() {
        lightBackground = !lightBackground;
        if (lightBackground) {
            panel.setBackground(LIGHT_CYAN);
            panel.setForeground(DEEP_TEAL);
            statusLabel.setForeground(new Color(0, 112, 105));
            label.setForeground(DEEP_TEAL);
            statusLabel.setText("Light cyan-green background selected.");
        } else {
            panel.setBackground(DEEP_TEAL);
            label.setForeground(Color.WHITE);
            statusLabel.setForeground(MINT);
            statusLabel.setText("Deep teal background selected.");
        }
        panel.repaint();
    }

    private void resetInterface() {
        label.setText("<html><div style='text-align:center;'>Welcome to Java Swing First<br>"
            + "Individual Assignment by Hannah Kondeh</div></html>");
        lightBackground = false;
        panel.setBackground(DEEP_TEAL);
        label.setForeground(Color.WHITE);
        statusLabel.setForeground(MINT);
        statusLabel.setText("Interface reset to its initial state.");
        panel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SwingAssignment::new);
    }
}
