package sl.edu.prog209;

import javax.swing.JFrame;
import java.awt.Dimension;

/**
 * Base window configuration shared by the assignment application.
 * This class demonstrates inheritance without duplicating SwingAssignment.
 */
public abstract class BaseWindow {
    protected final JFrame frame;

    protected BaseWindow() {
        frame = new JFrame("Java Swing Assignment");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(800, 800));
        frame.setLocationRelativeTo(null);
    }

    public JFrame getFrame() {
        return frame;
    }
}
