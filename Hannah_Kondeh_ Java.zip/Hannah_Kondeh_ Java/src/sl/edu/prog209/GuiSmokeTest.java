package sl.edu.prog209;

/**
 * Headless structural check. This does not prove that a visible GUI was manually tested.
 */
public final class GuiSmokeTest {
    private GuiSmokeTest() { }

    public static void main(String[] args) throws Exception {
        String source = java.nio.file.Files.readString(
            java.nio.file.Path.of("src/sl/edu/prog209/SwingAssignment.java"));
        String base = java.nio.file.Files.readString(
            java.nio.file.Path.of("src/sl/edu/prog209/BaseWindow.java"));
        require(source.contains("class SwingAssignment extends BaseWindow"), "inheritance declaration");
        require(source.contains("public SwingAssignment()"), "constructor");
        require(base.contains("new JFrame(\"Java Swing Assignment\")"), "frame title");
        require(base.contains("new Dimension(800, 800)"), "800 x 800 initial frame size");
        require(base.contains("JFrame.EXIT_ON_CLOSE"), "close operation");
        require(source.contains("new JPanel("), "JPanel");
        require(source.contains("new JLabel("), "JLabel");
        require(source.contains("new ImageIcon("), "ImageIcon");
        require(source.contains("changeLabelText"), "change text action");
        require(source.contains("toggleBackground"), "predefined background action");
        require(!source.contains("JColorChooser"), "no arbitrary colour picker");
        System.out.println("PASS: required source structure and restrictions detected.");
        System.out.println("LIMIT: visual GUI interactions still require manual testing in a desktop session.");
    }

    private static void require(boolean condition, String description) {
        if (!condition) {
            throw new IllegalStateException("FAILED: " + description);
        }
    }
}
