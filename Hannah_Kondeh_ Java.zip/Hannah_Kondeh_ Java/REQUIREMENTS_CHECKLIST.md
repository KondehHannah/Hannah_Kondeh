# Hannah Kondeh — requirements and evidence checklist

## Brief-derived checklist
- [x] Basic GUI implemented using Java Swing.
- [x] JFrame configured with title `Java Swing Assignment`, initial size 800 × 800 and exit-on-close.
- [x] JPanel created and added to frame.
- [x] JLabel created with the required welcome text and student's name.
- [x] Inheritance and constructor implemented.
- [x] `SwingAssignment` class created exactly once.
- [x] Custom application icon and `ImageIcon` usage included.
- [x] Change Text interaction implemented.
- [x] Change Background interaction implemented.
- [x] Figma design/evidence guidance documented.
- [x] README and source project included.
- [ ] Actual Figma wireframe created and genuine screenshot inserted.
- [ ] GUI manually launched and visually tested on a desktop.
- [ ] Genuine screenshots captured and inserted into report.
- [ ] GitHub repository created, all files committed, and lecturer invited as collaborator.
- [ ] Student's registration number and other missing identity details confirmed if required.

## Evidence placeholders to replace before submission
1. Figma wireframe screenshot (800 × 800 frame and all controls).
2. IntelliJ IDEA or VS Code screenshot showing the Java classes and package structure.
3. Running application screenshot showing initial state and H icon.
4. Change Text screenshot showing a changed label.
5. Change Background screenshot showing the alternate predefined background.
6. GitHub repository screenshot showing committed files and collaborator status.

Do not claim that the uncompleted evidence tasks are already done. The automated smoke check is structural only; it does not verify a visible desktop GUI.
